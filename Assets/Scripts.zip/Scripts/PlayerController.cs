using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// STARTER — Player controller for the "Orb Collector" lab goal.
/// Attach to a cube named "Player" (add a Rigidbody, freeze rotation X/Z).
///
/// COMPLETED WITH ALL TODO TASKS:
/// - TODO 1: OnCollisionEnter logs wall bumps.
/// - TODO 2: OnTriggerEnter collects and destroys orbs.
/// - TODO 3: LateUpdate handles smooth camera follow.
/// - TODO 5: OnDestroy spawns a bonus orb prefab at the last position.
/// </summary>
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Lab wiring (drag your objects here)")]
    [SerializeField] private GameObject orbPrefab;       // TODO 5: used to spawn a bonus orb
    [SerializeField] private Transform cameraTransform; // TODO 3: used by camera follow

    private Rigidbody rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Start()
    {
        Debug.Log("[PlayerController] Ready. Collect all orbs to win.");
    }

    void Update()
    {
        HandleMovement();
    }

    private void HandleMovement()
    {
        float h = Input.GetAxis("Horizontal"); // A/D + arrows
        float v = Input.GetAxis("Vertical");   // W/S + arrows

        Vector3 movement = new Vector3(h, 0f, v).normalized;

        // Time.deltaTime makes speed identical at any frame rate (10 FPS or 144 FPS).
        transform.Translate(movement * moveSpeed * Time.deltaTime, Space.World);
    }

    // TODO 1 (OnCollisionEnter): log the name of any wall you bump.
    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("Bumped into wall: " + collision.gameObject.name);
    }

    // TODO 2 (OnTriggerEnter): if other.CompareTag("Orb"), Destroy the orb and log collection.
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Orb"))
        {
            Debug.Log("Orb Collected!");

            GameManager.Instance.Collect();

            Destroy(other.gameObject);
        }
    }

    // TODO 3 (LateUpdate): move cameraTransform to player position + offset so it follows you smoothly.
    void LateUpdate()
    {
        if (cameraTransform != null)
        {
            Vector3 offset = new Vector3(0f, 12f, -8f);
            cameraTransform.position = Vector3.Lerp(cameraTransform.position, transform.position + offset, 5f * Time.deltaTime);
        }
    }

    // TODO 5 (OnDestroy): when the Player is destroyed, Instantiate one bonus orbPrefab at your last position.
    void OnDestroy()
    {
        if (orbPrefab != null)
        {
            Instantiate(orbPrefab, transform.position, transform.rotation);
        }
    }
}