using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// STARTER — A collectable orb for the "Orb Collector" lab goal.
/// Attach to a small sphere (scale 0.6), give it a Collider with
/// "Is Trigger" checked, and tag the object "Orb".
/// </summary>
public class Orb : MonoBehaviour
{
    [Header("Click palette")]
    [SerializeField] private Color[] clickColors = { Color.cyan, Color.magenta, Color.yellow };

    [Header("Bob & spin")]
    [SerializeField] private float bobHeight = 0.15f;
    [SerializeField] private float spinSpeed = 90f;

    [Header("Movement on Click")]
    [SerializeField] private float moveSpeed = 5f;
    private Vector3 moveDirection = Vector3.zero;
    private bool isMoving = false;

    private Vector3 basePosition;
    private Vector3 baseScale;
    private int clickIndex;
    private float hideTime = -1f;

    void Awake()
    {
        basePosition = transform.position;
        baseScale = transform.localScale;
    }

    void Update()
    {
        // 1. Standard bob and spin
        float bob = Mathf.Sin(Time.time * 3f) * bobHeight;
        
        // If it's moving, update the basePosition so it travels while bobbing
        if (isMoving)
        {
            basePosition += moveDirection * moveSpeed * Time.deltaTime;
        }

        transform.position = basePosition + Vector3.up * bob;
        transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.World);
    }

    private void OnMouseDown()
    {
        // Click the orb's collider → cycle its color.
        clickIndex = (clickIndex + 1) % clickColors.Length;
        GetComponent<Renderer>().material.color = clickColors[clickIndex];
        Debug.Log($"[Orb] Clicked → {clickColors[clickIndex]}");

        // GIVE IT A NEW DIRECTION UPON CLICK:
        // Option A: Move in a random horizontal direction
        moveDirection = new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f)).normalized;

        // Option B (Alternative): If you want it to always move forward relative to the camera or world, 
        // you could use Vector3.forward or transform.forward instead.

        isMoving = true;
    }
}